
$(document).ready(function(){

	$('.hw_testimonials_slider').slick({
		infinite: true,
		slidesToShow: 1,
		slidesToScroll: 1
	});

	$('.hw_awards_slider').slick({
		infinite: true,
		slidesToShow: 5,
		slidesToScroll: 1
	});


});


